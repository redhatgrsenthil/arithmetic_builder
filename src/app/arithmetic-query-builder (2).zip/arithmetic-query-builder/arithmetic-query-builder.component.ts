import { Component, OnInit, EventEmitter, Input, ViewChildren, AfterViewInit, QueryList, ElementRef, Output } from "@angular/core";
import { AlertService } from "../../shared/cui/alert/alert.service";

@Component({
  selector: "arithmetic-query-builder",
  templateUrl: "./arithmetic-query-builder.component.html",
  styleUrls: ["./arithmetic-query-builder.component.scss"],
})
export class ArithmeticQueryBuilderComponent implements OnInit, AfterViewInit {
  constructor(public cuiAlert: AlertService) { }
  @Input() group: any;
  _fields: any[];
  toggleObj = {};
  operators = [{ name: "Add (+)" }, { name: "Minus (-)" }, { name: "Multiply (*)" }, { name: "Divide (/)" }];

  @Input()
  get fields() {
    return this._fields;
  }
  set fields(_data: any[]) {
    if (_data) {
      this._fields = _data;
    }
  }
  @Input() disabled = false;
  @Output() onSave = new EventEmitter();
  @Output() onModified = new EventEmitter();

  conditions = [{ name: "Add (+)" }, { name: "Minus (-)" }, { name: "Multiply (*)" }, { name: "Divide (/)" }];

  groupAddObj = {
    condition: '',
    lField: '',
    lConstant: '',
    lConstantFlag: false,
    rField: '',
    rConstant: '',
    rConstantFlag: false,
    operator: '',
  };

  toggle(index) {
    this.toggleObj[index] = !this.toggleObj[index];
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }

  startValidating() {
    const stageValue = this.group.rules[this.group.rules.length - 1];
    if (stageValue && stageValue.condition != "" && stageValue.lField != "" && stageValue.rField != "") {
      this.onSave.emit('Validation success');
    }
    else {
      this.onSave.emit('Validation failure');
    }
  }

  addCondition() {
    if (this.group.rules.length == 0) {
      this.group.rules.push(Object.assign({}, this.groupAddObj));
    }
    else {
      const lastStage = this.group.rules[this.group.rules.length - 1];
      if (lastStage && lastStage.condition != "" && lastStage.lField != "" && lastStage.rField != "") {
        this.group.rules.push(Object.assign({}, this.groupAddObj));
      }
      else {
        this.cuiAlert.alert({ type: AlertService.ALERT_ERROR, message: 'Calculation stages cannot be empty.', src: 'dynamic-ui-side' });
      }
    }
    this.emitOnModified();
  }

  removeCondition(index) {
    if (this.disabled) {
      return false;
    }
    this.group.rules.splice(index, 1);
    this.emitOnModified();
  }

  addGroup() {
    this.group.rules.push({
      group: {
        operator: "+",
        rules: [],
      },
    });
    this.emitOnModified();
  }

  removeGroup() {
    // "group" in this.group.rules.splice(this.$index, 1);
    // this.emitOnModified();
  };

  emitOnModified() {
    this.onModified.emit('modified');
  }
  resetConstant($event, rule, label) {
    if ($event == false) {
      rule[label] = '1';
    }
  }

  showFormula() {
    console.log('this.group', this.group);
  }

}
